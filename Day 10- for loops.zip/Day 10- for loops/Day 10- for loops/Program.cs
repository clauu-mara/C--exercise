﻿using System;

namespace Day_10__for_loops
{

    class Computer
    {

        public int Adunare(int primulNumar, int alDoileaNumar)
        {
            int rezultat = primulNumar + alDoileaNumar;
            return rezultat;
        }
        public double Scadere(double primulNumar, double alDoileaNumar)
        {
            double rezultat = 0;
            if (primulNumar > alDoileaNumar)
            {
                rezultat = primulNumar - alDoileaNumar;
            }
            else
            {
                Console.WriteLine("Primul numar sa fie mai mare decat al doilea pentru a nu da valori negative! ");

            }
            return rezultat;
        }
        public float Inmultire(float primulNumar, float alDoileaNumar)
        {
            float rezultat = primulNumar * alDoileaNumar;
            return rezultat;
        }
        public double Impartire(double primulNumar, double alDoileaNumar)
        {
            double rezultat = 0;
            if (alDoileaNumar > 0)
            {
                rezultat = primulNumar / alDoileaNumar;
            }
            else
            {
                Console.WriteLine("Nu se poate face impartirea cu 0");
            }
            return rezultat;
        }
    }
    class LogicalOp
    {
        public int CheckBiggerNumber(int firstNumber, int secondNumber)
        {
            if (firstNumber > secondNumber)
            {
                return firstNumber;
            }
            else
            {
                return secondNumber;
            }

        }

        public String CheckStrings(string firstText)
        {
            string secondText = "FastTrackIT";
            string invalidText = "Got to try some more";

            if (firstText.Equals(secondText))
            {
                return "Learning text comparison";

            }
            else
            {
                return invalidText;
            }
        }

        public String CheckStringsAndIntegers(string text, int number)
        {
            if (text.Equals("FastTrackIT") && number <= 3)
            {
                string nr = number.ToString();
                return text + " " + nr;
            }
            else if (!text.Equals("FastTrackIT") && number >= 4)
            {
                return number.ToString() + " " + text;
            }
            else
            {
                return "No result";
            }
        }

        public String CheckTheAmountOfSnowInCm(int snowCm)
        {
            if (snowCm == 6 || snowCm > 8)
            {
                return "The amount of snow this winter was(cm): " + snowCm.ToString();
            }
            else
            {
                return "The forecast snow is(cm): " + snowCm.ToString();
            }
        }

        public String CheckNumber(int number)
        {
            if (number > 3 && number != 4)
            {
                return "The number is greater than 3 and not equal to 4";
            }
            else if (number == 4)
            {
                return " The number is equal to 4";
            }
            else if (number < 3)
            {
                return "The number is lower than 3";
            }
            else
            {
                return " The number is equal to 3";
            }
        }

        ///<summary>
        ///Creati o metoda care primeste un numar ca si parametru si sa afiseze ce numar a primit.
        ///Folosind constructia Switch-Case, verificati ce numar s-a primit si afisati textul "The number is:  x !" unde x trebuie sa reprezinte numarul apasat. 
        ///Pentru exemplul de fata sa nu se foloseasca concatenarea stringului "The number is:" cu numarul de la parametru, ci sa se scrie intreg textul cu tot cu numar pentru fiecare caz din Switch-Case.
        ///Apelati metoda in Main() pentru a verifica daca functioneaza.
        ///</summary>
        public void CheckTheNumber(int number)
        {
            switch (number)
            {
                case 1:
                    Console.WriteLine("The number is 1");
                    break;
                case 2:
                    Console.WriteLine("The number is 2");
                    break;
                case 3:
                    Console.WriteLine("The number is 3");
                    break;
                case 5:
                    Console.WriteLine("The number is 5");
                    break;
                case 6:
                    Console.WriteLine("The number is 6");
                    break;

                default:
                    Console.WriteLine("The number is: {0}", number);
                    break;

            }
        }
        public bool IsNumberEven(int number)
        {
            if (number % 2 == 0)
            {
                Console.WriteLine("True returned");
                return true;

            }
            else
            {
                Console.WriteLine("False returned");
                return false;

            }
        }

        public bool isEligibleToVote(int age)
        {
            if (age >= 18)
            {
                Console.WriteLine("Eligible to vote");
                return true;
            }
            else
            {
                Console.WriteLine("Not eligible to vote");
                return false;
            }

        }

        public double TheBiggestNumber(double firstNumber, double secondNumber, double thirdNumber)
        {
            if (firstNumber > secondNumber && firstNumber > thirdNumber)
                return firstNumber;
            else if (secondNumber > firstNumber && secondNumber > thirdNumber)
                return secondNumber;
            else
                return thirdNumber;
        }

        public void CountsUpTo100(int number)
        {
            Console.WriteLine("The number entered is:" + number);
            if (number <=100)
            {
                for (int i = number; i <= 100; i++)
                {
                    Console.WriteLine("Number: " + i);
                }
            }
        }

        public void CountsUpTo_100(int number)
        {
            Console.WriteLine("The number entered is:" + number);
            if (number <=-100)
            {
                Console.WriteLine("The limit has been reached");
            }else if(number >=-100)
            {
                for(int i=number; i>=-100;i--)
                {
                    Console.WriteLine("Number: " + i);
                }
            }
            
        }

        public void CountingBetweenAandB(int firstNumber, int secondNumber)
        {
            if(firstNumber>=0)
            {
                if (secondNumber > 0)
                {
                    for (int i = firstNumber; i <= secondNumber; i++)
                    {
                        Console.WriteLine("Number: " + i);
                    }
                }
                else
                {
                    for (int i = firstNumber; i >= secondNumber; i--)
                    {
                        Console.WriteLine("Number: " + i);
                    }
                }
            }
            else if(firstNumber <=0 )
            {
                if (secondNumber > 0)
                {
                    for (int i = firstNumber; i <= secondNumber; i++)
                    {
                        Console.WriteLine("Number: " + i);
                    }
                }
                else if( secondNumber <0 && firstNumber >secondNumber)
                {
                    for (int i = firstNumber; i >= secondNumber; i--)
                    {
                        Console.WriteLine("Number: " + i);
                    }
                }
                else
                {
                    for (int i = firstNumber; i <= secondNumber; i++)
                    {
                        Console.WriteLine("Number: " + i);
                    }
                }
            }
            else if(firstNumber==secondNumber)
            {
                Console.WriteLine("The numbers are equal:  " + firstNumber);
            }
            
        }

        public void CountingBetweenTwoNumbers(int firstNumber, int secondNumber)
        {
            int bigger= CheckBiggerNumber(firstNumber, secondNumber);
            if( bigger ==firstNumber)
            {
                Console.WriteLine("From {0} to {1}", secondNumber, bigger);
               for(int i=secondNumber;i<=bigger;i++)
                {
                    Console.WriteLine("Number:" + i);
                }
            }
            else
            {
                Console.WriteLine("From {0} to {1}", firstNumber, bigger);
                for (int i = firstNumber; i <= bigger; i++)
                {
                    Console.WriteLine("Number:" + i);
                }
            }
        }

        public void From1To100EvenNumbers()
        {
            Console.Write("Even numbers from 1 to 100 : ");
            for (int i=1;i<=100;i++)
            {
                
                if (i%2==0)
                {
                    Console.WriteLine(i);
                }
                else
                {
                    Console.WriteLine("Odd number");
                }
            }
        }

        public void From1To100OddNumbers()
        {
            Console.WriteLine("Odd numbers from 1 to 100 : ");
            for (int i = 1; i <= 100; i++)
            {
                if (i % 2 != 0)
                {
                    Console.WriteLine(i);
                }
                else
                {
                    Console.WriteLine("Even number");
                }
            }
        }

        public int Sum(int number)
        {
            if (number <= 100)
            {
                int sum = 0;
                for (int i = number; i <= 100; i++)
                {
                    sum += i;
                }
                return sum;
            }
            else
            {
                Console.WriteLine("The limits has been reached! ");
                return 0;
            }
        }

        public float ArithmeticAverage(int number)
        {
            if (number <= 100)
            {
                int sum = Sum(number);
                float average = sum / (100 - number);
                return average;
            }
            else
            {
                Console.WriteLine("The limits has been reached! ");
                return 0;
            }
           
        }

        public void Display(int n=7)
        {
            string[] array = new string[7];
            for(int i=0;i<7;i++)
            {
                for(int j=1;j<=7;j++)
                {
                    if (i + j < n + 1)
                        Console.Write("*");

                }
                Console.Write("\n");
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            //1
            Computer computer1 = new Computer();
            Console.WriteLine("Adunarea a doua numere:" + computer1.Adunare(23, 34));
            Console.WriteLine("Scaderea a doua numere: " + computer1.Scadere(9.4, 2.10));
            Console.WriteLine("Inmultirea a doua numere:" + computer1.Inmultire(2, 3));
            Console.WriteLine("Impartirea a doua numere:" + computer1.Impartire(14.5, 3));

            //2.3
            LogicalOp logicalOperations = new LogicalOp();
            int biggestNumber = logicalOperations.CheckBiggerNumber(20, 3);
            Console.WriteLine("The biggest number is : {0} ", biggestNumber);
            Console.WriteLine("The biggest number is : {0}", logicalOperations.CheckBiggerNumber(-1, 100));
            Console.WriteLine("The biggest number is : {0}", logicalOperations.CheckBiggerNumber(-31, -1));

            //2.4
            Console.Write("Enter text: ");
            string input = Console.ReadLine();
            string returnedText = logicalOperations.CheckStrings(input);
            Console.WriteLine("The returned result is: {0}", returnedText);

            //2.5
            Console.Write("Enter a text: ");
            input = Console.ReadLine();
            Console.Write("Enter a number: ");
            int number = int.Parse(Console.ReadLine());
            returnedText = logicalOperations.CheckStringsAndIntegers(input, number);
            Console.WriteLine("The returned result is: {0}", returnedText);

            //2.6
            //Console.Write("Enter a number: ");
            // number = int.Parse(Console.ReadLine());
            returnedText = logicalOperations.CheckTheAmountOfSnowInCm(number);
            Console.WriteLine("The returned result is: {0}", returnedText);

            //2.7
            Console.WriteLine("The returned result is: {0}", logicalOperations.CheckNumber(number));

            //2.8
            logicalOperations.CheckTheNumber(number);

            //2.9
            logicalOperations.IsNumberEven(number);

            //2.10
            logicalOperations.isEligibleToVote(number);

            //2.11
            Console.Write("Enter the first number: ");
            int number1 = int.Parse(Console.ReadLine());
            Console.Write("Enter the second number: ");
            int number2 = int.Parse(Console.ReadLine());
            Console.Write("Enter the third number: ");
            int number3 = int.Parse(Console.ReadLine());
            Console.WriteLine("The biggest number is: {0}", logicalOperations.TheBiggestNumber(number1, number2, number3));

            //for loops section
            //1.
            logicalOperations.CountsUpTo100(number);

            //2.
            logicalOperations.CountsUpTo_100(number);

            //3. ----- > ?
            Console.WriteLine("New line:");
            logicalOperations.CountingBetweenAandB(number1, number2);

            //4.
            logicalOperations.CountingBetweenTwoNumbers(number1, number2);

            //5.
            logicalOperations.From1To100EvenNumbers();

            //6.
            logicalOperations.From1To100OddNumbers();

            //7.
            Console.WriteLine(" The sum is:" + logicalOperations.Sum(number));

            //8.
            Console.WriteLine("The average of the numbers is : " + logicalOperations.ArithmeticAverage(number));

            //9.
            logicalOperations.Display();
        }
    }
}
