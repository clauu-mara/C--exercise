﻿using System;
using System.Collections.Generic;

namespace Day10_Lists_Optional
{
    class Program
    {
        /// <summary>
        /// 1.Scrieti o metoda C# care sa schimbe pozitia a doua elemente intr-o Lista
        /// </summary>
        /// <param name="listNumber"></param>
        /// <param name="initialPosition"></param>
        /// <param name="nextPosition"></param>
        public static void ChangePosition(List<int> listNumber, int initialPosition, int nextPosition)
        {
            int aux = 0;
            for(int i=0; i<listNumber.Count;i++)
            {
                if(i==initialPosition)
                {
                    aux = listNumber[i];
                    listNumber[i] = listNumber[nextPosition];
                    listNumber[nextPosition] = aux;
                }
            }
            Console.WriteLine("The list items are: ");
            foreach (int i in listNumber)
                Console.WriteLine(i);
        }

        /// <summary>
        /// 2.Scrieti o metoda C# care sa primeasca o Lista si sa returneze o alta lista, care sa contina doar numerele pare din lista primita.
        /// </summary>
        /// <param name="listNumber"></param>
        /// <returns></returns>
        public static List<int> EvenNumbers(List<int> listNumber)
        {
            List<int> evenNumberList = new List<int>();
            foreach(int i in listNumber)
            {
                if (i % 2 == 0)
                {
                   
                    evenNumberList.Add(i);
                    // throw System.ArgumentOutOfRangeException
                }
             
            }
            return evenNumberList;
        }
        /// <summary>
        /// 3.Scrieti o metoda C# care sa primeasca parametru o Lista nesortata, si sa returneze Lista sortata crescator. Atentie, sortarea sa se faca programatic(adica logica sa fie scrisa de voi), si nu folosit librarie externa, precum Collection.sort().
        /// </summary>
        /// <param name="listNumber"></param>
        /// <returns></returns>
        public static List<int> SortAscendingList(List<int> listNumber)
        {
            int aux;
            for(int i=0;i<listNumber.Count;i++)
                for(int j=i+1;j<listNumber.Count;j++)
                {
                    if(listNumber[i] > listNumber[j])
                    {
                        aux = listNumber[i];
                        listNumber[i] = listNumber[j];
                        listNumber[j] = aux;
                    }
                }
            return listNumber;
        }
        static void Main(string[] args)
        {
            List<int> listNumber = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9 };

            Console.WriteLine("Enter the starting position:");
            int initialPosition = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the next position:");
            int nextPosition = int.Parse(Console.ReadLine());

            //1
            ChangePosition(listNumber, initialPosition, nextPosition);

            //2 ==== am O PROBLEMA AICI
             List<int> evenNumberList = EvenNumbers(listNumber);
              Console.WriteLine("The even numbers are:");
              foreach (int i in evenNumberList)
                  Console.WriteLine(i);

            //3
            List<int> newListNumber= new List<int> { 4, 70, 21, 12, 6, 0, 1, 34, 5};
           // listNumber.Reverse();
            List<int> sortedList = SortAscendingList(newListNumber);
            Console.WriteLine("The sorted numbers are: ");
            foreach (int i in sortedList)
                Console.WriteLine(i);
        }
    }
}
