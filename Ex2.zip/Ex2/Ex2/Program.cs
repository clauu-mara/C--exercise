﻿using System;

namespace Ex2
{
    class Program
    {
        static float PI = 3.14f;
        static void Main(string[] args)
        {
            //1
            WriteInConsole(); //1
            AdditionFct(); //2
            Division(); //3
            Operations(); //4

            //2
            Console.WriteLine("Adunarea a doua nr:" + Adunare(5,3));
            Console.WriteLine("Adunarea a doua nr:" + Scadere(23,9));
            Console.WriteLine("Adunarea a doua nr:" + Scadere(-3, 9));
            Console.WriteLine("Adunarea a doua nr:" + Inmultire(10, 10));
            Console.WriteLine("Adunarea a doua nr:" + Impartire(10, 3));

            //3
            AfisareCSharp();

            //4
            Console.WriteLine("Media aritmetica a 3 numere este : " + MediaAritmetica(18, 3, 29));
            //5
            Console.WriteLine("Restul impartirii a doua numere este : " + RestulImpartirii(50,9));
            //6
            Console.WriteLine("Temperatura in grade Celsius: " + ConvertFahrenheitToCelsius(30));
            //7 
            Console.WriteLine("Convertire inchi in metrii: " + ConvertInchToMeters(2000));
            //8
            Viteaza(5,2,30,20);

            //9
            RazaCerc(3);
        }

        public static void WriteInConsole()
        {
            Console.WriteLine("Hello \nClaudia");
        }

        public static void AdditionFct()
        {
            Console.Write("Enter nr1: ");
            string input1 = Console.ReadLine();
            Console.Write("Enter nr2: ");
            string input2 = Console.ReadLine();
            int n1 = int.Parse(input1);
            int n2 = int.Parse(input2);
            Console.WriteLine("Rezultatul adunarii: " + (n1 + n2));


        }
        public static void Division()
         {
            double nr1 = 10, nr2 = 3, result;

            if (nr2 >0)
            {
                result = nr1 / nr2;
                Console.WriteLine("Rezultatul impartirii a doua numere este: " + result);
            }
            else
            {
                Console.WriteLine("Cannot be divided by 0");
            }
            double res1 = (double)10 / 3;
           
            Console.WriteLine("Rezultatul impartirii a doua numere este: " + res1);
         }

        public static void Operations()
        {
            double rezultat = (20 + (double)(-3 * 5) / 8);
            Console.WriteLine("Rezultatul urmatoarelor operatii a.: " + (-5 + (8 * 6)));
            Console.WriteLine("Rezultatul urmatoarelor operatii b.: " + (55 + 9) % 9);
            Console.WriteLine("Rezultatul urmatoarelor operatii c.: " + rezultat);
            Console.WriteLine("Rezultatul urmatoarelor operatii d.: " + (5 + (15 / (3 * 2)) - 8 % 3));
        }


        public static int Adunare(int primulNumar, int alDoileaNumar)
        {
            int rezultat = primulNumar + alDoileaNumar;
            return rezultat;
        }
        public static double Scadere(double primulNumar, double alDoileaNumar)
        {
            double rezultat = 0;
            if (primulNumar > alDoileaNumar)
            {
                rezultat = primulNumar - alDoileaNumar;
            }
            else
            {
                Console.WriteLine("Primul numar sa fie mai mare decat al doilea pentru a nu da valori negative! ");
            }
            return rezultat;
        }
        public static float Inmultire(float primulNumar, float alDoileaNumar)
        {
            float rezultat =primulNumar*alDoileaNumar;
            return rezultat;
        }
        public static double Impartire(double primulNumar, double alDoileaNumar)
        {
            double rezultat=0;
            if (alDoileaNumar> 0)
            {
                rezultat = primulNumar / alDoileaNumar;
            }
            else
            {
                Console.WriteLine("Nu se poate face impartirea cu 0");
            }
            return rezultat;
        }

        public static void AfisareCSharp()
        {
            Console.WriteLine("    C C C          /                   /");
            Console.WriteLine("C             ----/-------------------/----");
            Console.WriteLine("C                /                   /");
            Console.WriteLine("C               /                   /");
            Console.WriteLine("C          ----/-------------------/----");
            Console.WriteLine("    C C C     /                   /");
        }

        public static double MediaAritmetica(int primulNumar, int alDoileaNumar, int alTreileaNumar)
        {
            double media = (primulNumar + alDoileaNumar + alTreileaNumar) / 3;
            return media;
        }

        public static double RestulImpartirii(double primulNumar, double alDoileaNumar)
        {
            double restul =0;
            if (alDoileaNumar > 0)
            {
                 restul = primulNumar % alDoileaNumar;
            }
            else
            {
                Console.WriteLine("Nu se poate face impartirea cu 0.");
            }
            return restul;
        }

        public static float ConvertFahrenheitToCelsius(float temperaturaFahrenheit)
        {
            float temperaturaCelsius = 5 / 9 * (temperaturaFahrenheit - 32);
            return temperaturaCelsius;
        }
        public static double ConvertInchToMeters(double inch)
        {
            double meters = inch / 39.370;
            return meters;
        }

        public static void Viteaza(double distanta, int ora, int minut, int secunda)
        {
            double vitezaMetriPeSecunda, vitezaKm, vitezaMile;
            int secunde;
            secunde = (ora *3600 + minut*60 +secunda);
            vitezaMetriPeSecunda = distanta / secunde;
            vitezaKm = (distanta / 1000) / (secunde/3600);
            vitezaMile = (distanta / 1609) / (secunde/3600);
            Console.WriteLine("Viteza in m/s: " + vitezaMetriPeSecunda);
            Console.WriteLine("Viteza in km/h: " + vitezaKm);
            Console.WriteLine("Viteza in mile/h:  " + vitezaMile);
        }
        
        public static void RazaCerc(float raza)
        {
            Console.WriteLine("Perimetru: " + (2*PI*raza));
            Console.WriteLine("Aria: " + PI*(raza*raza));
        }
    }
    



}
