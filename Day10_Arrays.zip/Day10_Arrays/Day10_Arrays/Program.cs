﻿using System;

namespace Day10_Arrays
{


    class Computer
    {

        public int Adunare(int primulNumar, int alDoileaNumar)
        {
            int rezultat = primulNumar + alDoileaNumar;
            return rezultat;
        }

        public int Adunare(int primulNumar, int alDoileaNumar, int alTreileaNumar, int alPatruleaNumar)
        {
            int rezultat = primulNumar + alDoileaNumar + alTreileaNumar+alPatruleaNumar;
            return rezultat;
        }
        public double Adunare(int primulNumar, double alDoileaNumar)
        {
            double rezultat = primulNumar + alDoileaNumar;
            return rezultat;
        }
        public double Scadere(double primulNumar, double alDoileaNumar)
        {
            double rezultat = 0;
            if (primulNumar > alDoileaNumar)
            {
                rezultat = primulNumar - alDoileaNumar;
            }
            else
            {
                Console.WriteLine("Primul numar sa fie mai mare decat al doilea pentru a nu da valori negative! ");

            }
            return rezultat;
        }
        public int Scadere(int primulNumar, int alDoileaNumar, int alTreileaNumar)
        {
            int rezultat = primulNumar - alDoileaNumar - alTreileaNumar;
            if (rezultat == 0)
                return 0;
            else if (rezultat < 0)
                return -1;
            else
                return rezultat;
        }
        public double Scadere(double primulNumar, double alDoileaNumar, int alTrieleaNumar,int alPatruleaNumar)
        {
            double rezultat = primulNumar - alDoileaNumar - alTrieleaNumar - alPatruleaNumar;
            if (rezultat == 0)
                return 0;
            else if (rezultat < 0)
                return -1;
            else
                return rezultat;
        }
        public float Inmultire(float primulNumar, float alDoileaNumar)
        {
            float rezultat = primulNumar * alDoileaNumar;
            return rezultat;
        }
        public int Inmultire(int primulNumar, int alDoileaNumar, float alTreileaNumar)
        {
            int rezultat = primulNumar * alDoileaNumar * (int)alTreileaNumar;
            return rezultat;
        }
        public float Inmultire(float primulNumar,int alDoileaNumar, double alTreileaNumar)
        {
            float rezultat = primulNumar * alDoileaNumar * (float)alTreileaNumar;
            return rezultat;
        }
        public double Impartire(double primulNumar, double alDoileaNumar)
        {
            double rezultat = 0;
            if (alDoileaNumar > 0)
            {
                rezultat = primulNumar / alDoileaNumar;
            }
            else
            {
                Console.WriteLine("Nu se poate face impartirea cu 0");
            }
            return rezultat;
        }
        public double Impartire( int primulNumar, double alDoileaNumar, float alTreileaNumar)
        {
            double rezultat = 0;
            if (alDoileaNumar > 0 && alTreileaNumar>0 )
            {
                rezultat = (primulNumar / alDoileaNumar) /alTreileaNumar;
            }
            else
            {
                Console.WriteLine("Nu se poate face impartirea cu 0");
            }
            return rezultat;
        }
        public float Impartire(int primulNumar, float alDoileaNumar, int alTreileaNumar)
        {
            float rezultat = 0;
            if (alDoileaNumar > 0 && alTreileaNumar > 0)
            {
                rezultat = (primulNumar / alDoileaNumar) / alTreileaNumar;
            }
            else
            {
                Console.WriteLine("Nu se poate face impartirea cu 0");
            }
            return rezultat;
        }
    }

    class LogicalOp
    {
        public void FillArray(int n=100)
        {
            int[] array = new int[100];
            for(int i=0;i<n;i++)
            {
                array[i] = i + 1;
                Console.WriteLine("The element {0}:{1} ", i, array[i]);
            }
        }

        public int[] EvenNumbers(int[] array)
        {
            array = new int[50];
            int nr = 0;
            for(int i=1;i<=100;i++)
            {
                if(i%2==0)
                {
                    
                    array[nr] = i;
                    nr++;
                }
            }
            return array;
        }

        public float ArithmeticAverage(int[] array1)
        {
            int sum = 0;
            float average = 0;
            foreach(int i in array1)
            {
                sum += i;

            }
            if (array1.Length > 0)
            {
                average = sum / array1.Length;
            }
            else if(array1.Length==0)
            {
                Console.WriteLine("Dividing by zero is undefined");
            }
            else
            {
                Console.WriteLine("The length can't be negative");
            }
            return average;
        }

        public bool CheckTheString(string[] array, string text)
         {

             foreach (string i in array)
             {
                 if(i.Equals(text))
                     return true;
             }
            return false;
         }

        public int CheckTheNumber(int[] array, int number)
        {
            int position = 0;
            for (int i = 0; i < array.Length; i++)
            {
                if (array[i]==number)
                {
                    position = i;
                    break;
                }
                else
                {
                    position= -1;
                }

            }
            return position;
        }

        public void Display(char[,] array)
        {
            array = new char[10, 10];
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    array[i, j] = '-';
                }
            }
            for(int i=0;i<10;i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    Console.Write(" " + array[i, j]);
                }
                Console.Write("\n");
            }
                
        }

        public int[] ReturnArray(int[] array, int number)
        {
            int[] newArray = new int[array.Length];
            int index=0;
            for(int i=0;i<array.Length;i++)
                if(array[i]==number)
                {
                    index = i;
                }
            for (int j = 0; j < index; j++)
                newArray[j] = array[j];
            for (int j = index + 1; j < array.Length; j++)
            {
                newArray[index] = array[j];
                index++;
            }
            return newArray;
        }

        public int SecondBiggestNumber(int[] array)
        {
            int max=0;
            Array.Sort(array);
            Array.Reverse(array);
            int i = 1;
            if (array[0] != array[i])
            {
                max = array[i];

            }
            else
            {
                i++;
            }
            return max;

        }

        public void CloneArray(int[] array)
        {
            int[] cloneArray = array.Clone() as int[];
            Console.WriteLine("Clone of the array:");
            foreach (int i in cloneArray)
                Console.WriteLine(i);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            //ex 1
            Computer computer = new Computer();
            Console.WriteLine("Adunare:" + computer.Adunare(23, 23));
            Console.WriteLine("Adunare:" + computer.Adunare(23, 23,12,2));
            Console.WriteLine("Adunare:" + computer.Adunare(23, 23.2));

            Console.WriteLine("Scadere:" + computer.Scadere(45.2, 12.6));
            Console.WriteLine("Scadere:" + computer.Scadere(45, 12));
            Console.WriteLine("Scadere:" + computer.Scadere(40.1, 12.3,3,4));

            Console.WriteLine("Inmultire: " +computer.Inmultire(122,42));
            Console.WriteLine("Inmultire: " +computer.Inmultire(30,6,10.5));
            Console.WriteLine("Inmultire: " +computer.Inmultire(5,8,203));

            Console.WriteLine("Impartire:" +computer.Impartire(23,5));
            Console.WriteLine("Impartire:" +computer.Impartire(10,2.3,3));
            Console.WriteLine("Impartire:" + computer.Impartire(200, 30, 4));


            LogicalOp logicalOperations = new LogicalOp();
            //ex 2
            logicalOperations.FillArray();

            //ex 3
            int[] array = null;
            int[] array1 = logicalOperations.EvenNumbers(array);
            Console.WriteLine("The elements of the array are:" );
            foreach (int i in array1)
                Console.WriteLine("Element: "+i);

            //ex 4
            Console.WriteLine("The average is :" + logicalOperations.ArithmeticAverage(array1));

            //ex 5
            string[] arraySting = new string[]{ "Element1", "Element2", "Element3", "Element4"};
            //string text = "Element2";
            Console.Write("Enter a text:");
            string input = Console.ReadLine();
            bool valid = logicalOperations.CheckTheString(arraySting, input);
            Console.WriteLine("Validation: "+ valid);

            //ex 6
            Console.Write("Enter a number:");
            int number = int.Parse(Console.ReadLine());
            int position = logicalOperations.CheckTheNumber(array1, number);
            Console.WriteLine("The position of the number found is:" + position);


            //ex 7
            char[,] charArray = null;
            logicalOperations.Display(charArray);

            //ex 8
            array = logicalOperations.ReturnArray(array1, number);
            Console.WriteLine("The array is: " );
            foreach (int i in array)
            {
                Console.WriteLine(i);
            }
            //ex 9
            Console.WriteLine("The second biggest number is :" +logicalOperations.SecondBiggestNumber(array1));

            // ex 10
            logicalOperations.CloneArray(array1);


            Console.ReadLine();
        }
    }
}
