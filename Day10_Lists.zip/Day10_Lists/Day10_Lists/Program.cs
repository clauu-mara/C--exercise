﻿using System;
using System.Collections.Generic;

namespace Day10_Lists
{
    class Program
    {
        public static void DisplayTheList(List<int> listNumber)
        {
            foreach (int i in listNumber)
            {
                Console.WriteLine("Element:" + i);
            }
        }

        public static void InsertNumber(List<int> listNumber, int number)
        {
            listNumber.Insert(index: listNumber.Count, number);
            //foreach (int i in listNumber)
            //  Console.WriteLine("Element:" + i);
            listNumber.ForEach(Console.WriteLine);
        }

        public static void DisplayNumbers(List<int> listNumber, int number)
        {
           foreach(int i in listNumber)
            {
                if (i.Equals(number))
                {
                    Console.WriteLine("Element:" + i);
                    for(int j=number;j<listNumber.Count;j++)
                    {
                        Console.WriteLine("Element:" + listNumber[j]);
                    }
                }
                  

            }
        }

        public static void ReverseList(List<int> listNumber)
        {
            listNumber.Reverse();
            Console.WriteLine("The elements of the list are:");
            foreach(int i in listNumber)
            {
                Console.WriteLine(i);
            }
        }

        public static void InsertString(List<string> listString, int number, string text)
        {
            listString.Insert(index: number, text);
                listString.ForEach(Console.WriteLine);
        }

        public static void InsertFloat(List<float> listFloat, int number)
        {
            listFloat.Insert(index: 0, number);
            listFloat.ForEach(item => Console.WriteLine("Element: " + item));
        }
        
        public static void DisplayList(List<float> listFloat)
        {
            for (int i = 0; i < listFloat.Count; i++)
                Console.WriteLine(" On position {0} is the value {1}", i, listFloat[i]);
        }

        public static float TheBiggestNumber(List<float> listFloat)
        {
            float max = listFloat[0];
            for(int i=1;i<listFloat.Count;i++)
            {
                if (listFloat[i] > max)
                    max = listFloat[i];
            }
            return max;
        }
        static void Main(string[] args)
        {
            List<int> listNumber= new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            List<float> listFloat = new List<float> { 12, 13, 14, 15, 16, 17, 18, 19, 20 };
            //ex 1
            DisplayTheList(listNumber);

            //ex 2
            Console.Write("Enter a number:");
            int input = int.Parse(Console.ReadLine());
            InsertNumber(listNumber, input);

            //ex 3
            Console.Write("Enter another number:");
            input = int.Parse(Console.ReadLine());
            DisplayNumbers(listNumber, input);

            //ex 4
            ReverseList(listNumber);

            //ex 5
            List<string> listString = new List<string> { "Element1", "Element2", "Element3", "Element4", "Element5" };
            Console.Write("Enter a text:");
            string inputString = Console.ReadLine();
            InsertString(listString, input, inputString);

            //ex 6
            Console.WriteLine("The float list is: ");
            InsertFloat(listFloat, input);

            //ex 7
            DisplayList(listFloat);

            //ex 8
            listFloat.Insert(index: 4, 30);
            Console.WriteLine("The biggest number is : " + TheBiggestNumber(listFloat));
        }
    }
}
