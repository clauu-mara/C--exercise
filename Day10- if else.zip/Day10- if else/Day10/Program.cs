﻿using System;

namespace Day10
{

    class Computer
    {

        public  int Adunare(int primulNumar, int alDoileaNumar)
        {
            int rezultat = primulNumar + alDoileaNumar;
            return rezultat;
        }
        public  double Scadere(double primulNumar, double alDoileaNumar)
        {
            double rezultat = 0;
            if (primulNumar > alDoileaNumar)
            {
                rezultat = primulNumar - alDoileaNumar;
            }
            else
            {
                Console.WriteLine("Primul numar sa fie mai mare decat al doilea pentru a nu da valori negative! ");

            }
            return rezultat;
        }
        public  float Inmultire(float primulNumar, float alDoileaNumar)
        {
            float rezultat = primulNumar * alDoileaNumar;
            return rezultat;
        }
        public double Impartire(double primulNumar, double alDoileaNumar)
        {
            double rezultat = 0;
            if (alDoileaNumar > 0)
            {
                rezultat = primulNumar / alDoileaNumar;
            }
            else
            {
                Console.WriteLine("Nu se poate face impartirea cu 0");
            }
            return rezultat;
        }
    }
    class LogicalOp
    {
        public int CheckBiggerNumber(int firstNumber, int secondNumber)
        { 
            if(firstNumber>secondNumber)
            {
                return firstNumber;
            }else
            {
                return secondNumber;
            }

        }

        public String CheckStrings(string firstText)
        {
            string secondText = "FastTrackIT";
            string invalidText = "Got to try some more";

            if ( firstText.Equals(secondText))
            {
                return "Learning text comparison";

            }
            else
            {
                return invalidText;
            }    
        }

        public String CheckStringsAndIntegers(string text, int number)
        {
            if( text.Equals("FastTrackIT") && number<=3)
            {
                string nr = number.ToString();
                return text + " "+ nr;
            }
            else if( !text.Equals("FastTrackIT") && number>=4)
            {
                return number.ToString()+" " + text;
            }
            else
            {
                return "No result";
            }
        }

        public String CheckTheAmountOfSnowInCm(int snowCm)
        {
            if(snowCm == 6 || snowCm > 8)
            {
                return "The amount of snow this winter was(cm): " +snowCm.ToString() ;
            }
            else
            {
                return "The forecast snow is(cm): "+snowCm.ToString();
            }
        }

        public String CheckNumber(int number)
        {
            if( number>3 && number!=4)
            {
                return "The number is greater than 3 and not equal to 4";
            }
            else if( number ==4)
            {
                return " The number is equal to 4";
            }
            else if( number<3)
            {
                return "The number is lower than 3";
            }
            else
            {
                return " The number is equal to 3";
            }
        }

        public void CheckTheNumber(int number)
        {
           switch(number)
           {
                case 1:
                    Console.WriteLine("The number is 1");
                    break;
                case 2:
                    Console.WriteLine("The number is 2");
                    break;
                case 3:
                    Console.WriteLine("The number is 3");
                    break;
                case 5:
                    Console.WriteLine("The number is 5");
                    break;
                case 6:
                    Console.WriteLine("The number is 6");
                    break;

                default:
                    Console.WriteLine("The number is: {0}", number);
                    break;

            }
        }
        public bool IsNumberEven(int number)
        {
            if (number % 2 == 0)
            {
                Console.WriteLine("True returned");
                return true;
                
            }
            else
            {
                Console.WriteLine("False returned");
                return false;
              
            }
        }
        
        public bool isEligibleToVote(int age)
        {
            if (age >= 18)
            {
                Console.WriteLine("Eligible to vote");
                return true;
            }
            else
            {
                Console.WriteLine("Not eligible to vote");
                return false;
            }

        }

        public double TheBiggestNumber(double firstNumber, double secondNumber, double thirdNumber)
        {
            if (firstNumber > secondNumber && firstNumber > thirdNumber)
                return firstNumber;
            else if (secondNumber > firstNumber && secondNumber > thirdNumber)
                return secondNumber;
            else
                return thirdNumber;
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            //1
            Computer computer1 = new Computer();
            Console.WriteLine("Adunarea a doua numere:"+computer1.Adunare(23, 34));
            Console.WriteLine("Scaderea a doua numere: " + computer1.Scadere(9.4, 2.10));
            Console.WriteLine("Inmultirea a doua numere:" + computer1.Inmultire(2, 3));
            Console.WriteLine("Impartirea a doua numere:" +computer1.Impartire(14.5, 3));

            //2.3
            LogicalOp logicalOperations = new LogicalOp();
            int biggestNumber = logicalOperations.CheckBiggerNumber(20, 3);
            Console.WriteLine("The biggest number is : {0} ", biggestNumber);
            Console.WriteLine("The biggest number is : {0}", logicalOperations.CheckBiggerNumber(-1, 100));
            Console.WriteLine("The biggest number is : {0}", logicalOperations.CheckBiggerNumber(-31,-1 ));

            //2.4
            Console.Write("Enter text: ");
            string input = Console.ReadLine();
            string returnedText = logicalOperations.CheckStrings(input);
            Console.WriteLine("The returned result is: {0}", returnedText);

            //2.5
            Console.Write("Enter a text: ");
            input = Console.ReadLine();
            Console.Write("Enter a number: ");
            int number=int.Parse(Console.ReadLine());
            returnedText = logicalOperations.CheckStringsAndIntegers(input, number);
            Console.WriteLine("The returned result is: {0}", returnedText);

            //2.6
            //Console.Write("Enter a number: ");
           // number = int.Parse(Console.ReadLine());
            returnedText = logicalOperations.CheckTheAmountOfSnowInCm(number);
            Console.WriteLine("The returned result is: {0}", returnedText);

            //2.7
            Console.WriteLine("The returned result is: {0}",logicalOperations.CheckNumber(number));

            //2.8
            ///<summary>
            ///Creati o metoda care primeste un numar ca si parametru si sa afiseze ce numar a primit.
            ///Folosind constructia Switch-Case, verificati ce numar s-a primit si afisati textul "The number is:  x !" unde x trebuie sa reprezinte numarul apasat. 
            ///Pentru exemplul de fata sa nu se foloseasca concatenarea stringului "The number is:" cu numarul de la parametru, ci sa se scrie intreg textul cu tot cu numar pentru fiecare caz din Switch-Case.
            ///Apelati metoda in Main() pentru a verifica daca functioneaza.
            ///</summary>
            logicalOperations.CheckTheNumber(number);

            //2.9
            logicalOperations.IsNumberEven(number);

            //2.10
            logicalOperations.isEligibleToVote(number);

            //2.11
            Console.Write("Enter the first number: ");
            double number1 = int.Parse(Console.ReadLine());
            Console.Write("Enter the second number: ");
            double number2 = int.Parse(Console.ReadLine());
            Console.Write("Enter the third number: ");
            double number3 = int.Parse(Console.ReadLine());
            Console.WriteLine("The biggest number is: {0}", logicalOperations.TheBiggestNumber(number1, number2, number3 ));



        }
    }
}
