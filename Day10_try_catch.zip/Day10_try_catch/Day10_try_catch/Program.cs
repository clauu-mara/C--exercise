﻿using System;
using System.Collections.Generic;

namespace Day10_try_catch
{
    class Read
    {
        public double Treat()
        {
            double input = 0;
            Console.WriteLine("Enter a number:");
            try
            {
                input = double.Parse(Console.ReadLine());
                Console.Write("The number is:");

            }
            catch (Exception e)
            {
                Console.WriteLine("No number was entered.Please try again!");
                input = -1;
            }

            return input;
        }


        public int Treat(int input = 0)
        {
            Console.WriteLine("Enter a number:");
            try
            {
                input = int.Parse(Console.ReadLine());
                Console.Write("The number is:");

            }
            catch (Exception e)
            {
                Console.WriteLine("No number was entered.Please try again!");
                input = -1;
            }

            return input;
        }

        public float Treat(float input = 0)
        {
            Console.WriteLine("Enter a number:");
            try
            {
                input = int.Parse(Console.ReadLine());
                Console.Write("The number is:");

            }
            catch (Exception e)
            {
                Console.WriteLine("No number was entered.Please try again!");
                input = -1;
            }

            return input;
        }

        public int[] CreateArray(int positions)
        {
            int[] array = new int[positions];
          try
          {
            
            Console.WriteLine("Enter the elements:");
            for(int i=0;i<positions;i++)
            {
                    
                    Console.Write("On position {0} is :", i);
                    array[i] = int.Parse(Console.ReadLine());


            }
          }
          catch(Exception e)
          {
                Console.WriteLine("No number was entered.Please try again");
               
          }
            return array;
        }

        public List<int> CreateList()
        {
            List<int> listNumber=null;
            try 
            {
                Console.WriteLine("Elements are:");
                listNumber = new List<int>() ;
                string number = Console.ReadLine();
                if(Convert.ToInt32(number)==int.Parse(Console.ReadLine()))
                {
                    listNumber.Add(int.Parse(Console.ReadLine()));
                }    
            }
            catch(Exception e)
            {
                Console.WriteLine("No number was entered");
                
            }
            return listNumber;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Read objectRead = new Read();
            //ex 1
            Console.WriteLine(objectRead.Treat());

            //ex 2
            Console.WriteLine(objectRead.Treat());
            Console.WriteLine(objectRead.Treat());

            //ex 3
           
            Console.WriteLine("Enter the number of the positions:");
            int input = int.Parse(Console.ReadLine());
            int[] array = objectRead.CreateArray(input);
            Console.WriteLine("Elements of the array are:");
            foreach (int i in array)
                Console.WriteLine(i);

            //ex 4
            List<int> listNumbers = objectRead.CreateList();
            foreach (int list in listNumbers)
                Console.WriteLine(list);
        }
    }
}
