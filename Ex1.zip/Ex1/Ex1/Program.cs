﻿using System;

namespace Ex1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Ex 1
            Console.WriteLine("Hello");
            Console.WriteLine("Claudia");
            Console.WriteLine("Hello \nClaudia");

            // Ex2
            int n1 = 12, n2 = 4, rez=0;
            rez = n1 + n2;
            Console.WriteLine("Rezultatul adunarii a doua nr: " + rez);

            Console.Write("Enter nr1: ");
            string input1 = Console.ReadLine();
            Console.Write("Enter n2: ");
            string input2 = Console.ReadLine();
            n1 = int.Parse(input1);
            n2 = int.Parse(input2);

            Console.WriteLine("Rezultatul adunarii: " + (n1 + n2));
            //Ex3 
            double nr1=10, nr2=3, result;
            result =nr1/nr2;
            double res1 = (double) 10 / 3;
            Console.WriteLine("Rezultatul impartirii a doua numere este: " + result);
            Console.WriteLine("Rezultatul impartirii a doua numere este: " + res1);

            //Ex4
            double rezultat= (20 + (double)(-3 * 5) / 8);
            Console.WriteLine("Rezultatul urmatoarelor operatii a.: " + (-5+(8*6)));
            Console.WriteLine("Rezultatul urmatoarelor operatii b.: " + (55 + 9) % 9);
            Console.WriteLine("Rezultatul urmatoarelor operatii b.: " + rezultat);
            Console.WriteLine("Rezultatul urmatoarelor operatii b.: " + (5 + (15 / (3 * 2)) - 8 % 3));
        }
    }
}
